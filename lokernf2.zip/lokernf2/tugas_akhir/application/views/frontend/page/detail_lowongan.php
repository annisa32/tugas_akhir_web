<div class="row pt-4">
    <div class="col-md-12">
        <div class="list-lowongan">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title"><?= $data[0]->nama_perusahaan ?></h4>
                    <p class="card-text"><?= $data[0]->deskripsi_pekerjaan ?></p>
                    <p class="card-text"><?= $data[0]->deskripsi_kualifikasi_pekerjaan ?></p>
                    <span><?= $data[0]->tanggal_akhir ?></span>
                </div>
            </div>
        </div>
    </div>
</div>